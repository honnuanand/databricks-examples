def greet(name):
    return f"Hello, {name}! Welcome to Databricks."

def add(a, b):
    return a + b

def multiply(a, b):
    return a * b
